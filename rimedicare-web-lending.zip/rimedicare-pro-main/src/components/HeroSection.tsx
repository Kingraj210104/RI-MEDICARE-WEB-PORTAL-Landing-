
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { ArrowRight, ChevronRight } from 'lucide-react';

const HeroSection = () => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <section className="relative py-24 md:py-32 overflow-hidden">
      {/* Background gradient effect */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-48 -right-48 w-96 h-96 rounded-full bg-brand-100 mix-blend-multiply opacity-70 blur-3xl"></div>
        <div className="absolute -bottom-48 -left-48 w-96 h-96 rounded-full bg-medicare-100 mix-blend-multiply opacity-70 blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 relative">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
            <div className={`w-full lg:w-1/2 space-y-8 text-center lg:text-left transition-all duration-700 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
              <div className="inline-block bg-brand-50 px-4 py-1.5 rounded-full text-brand-700 font-medium text-sm mb-2 border border-brand-100">
                Buy Now, Pay Later for Healthcare
              </div>
              <h1 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl tracking-tight text-gray-900 leading-tight">
                <span className="text-gradient">Affordable</span> Healthcare Financing
              </h1>
              <p className="text-lg md:text-xl text-gray-600 max-w-xl mx-auto lg:mx-0">
                Get medical treatment today, pay later! With flexible EMI plans and instant approvals, we make healthcare accessible for everyone.
              </p>
              <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6 justify-center lg:justify-start">
                <Link to="/apply-loan">
                  <Button size="lg" className="w-full sm:w-auto bg-brand-600 hover:bg-brand-700 text-base flex items-center gap-2 group">
                    Apply Now
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Button>
                </Link>
                <Link to="/hospital-registration">
                  <Button variant="outline" size="lg" className="w-full sm:w-auto text-base flex items-center gap-2 group">
                    Get Started
                    <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Button>
                </Link>
              </div>
              <div className="pt-4 flex items-center justify-center lg:justify-start gap-8">
                <div className="flex flex-col items-center lg:items-start">
                  <span className="text-3xl font-bold text-gray-900">500+</span>
                  <span className="text-sm text-gray-500">Partner Hospitals</span>
                </div>
                <div className="flex flex-col items-center lg:items-start">
                  <span className="text-3xl font-bold text-gray-900">20K+</span>
                  <span className="text-sm text-gray-500">Happy Patients</span>
                </div>
                <div className="flex flex-col items-center lg:items-start">
                  <span className="text-3xl font-bold text-gray-900">90</span>
                  <span className="text-sm text-gray-500">Days Interest-Free</span>
                </div>
              </div>
            </div>
            <div className={`w-full lg:w-1/2 relative transition-all duration-700 delay-300 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
              <div className="relative aspect-square md:aspect-[4/3] max-w-lg mx-auto">
                {/* Hero Image */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="relative w-full h-full">
                    <div className="absolute -top-4 -right-4 w-24 h-24 bg-brand-200 rounded-full mix-blend-multiply animate-float opacity-60"></div>
                    <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-medicare-200 rounded-full mix-blend-multiply animate-float opacity-60" style={{ animationDelay: '2s' }}></div>
                    
                    <div className="relative w-full h-full rounded-2xl overflow-hidden shadow-xl glassmorphism">
                      <div className="absolute inset-0 bg-gradient-to-br from-brand-50 to-medicare-50 opacity-90"></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-full max-w-sm p-8">
                          <div className="flex justify-between items-center mb-6">
                            <div className="text-xl font-semibold text-gray-900">RI Medicare Card</div>
                            <div className="w-12 h-8 bg-gradient-to-r from-brand-500 to-medicare-500 rounded-md"></div>
                          </div>
                          <div className="w-full h-12 bg-gray-200 rounded-md mb-6"></div>
                          <div className="space-y-3">
                            <div className="flex justify-between">
                              <div className="w-20 h-3 bg-gray-300 rounded"></div>
                              <div className="w-20 h-3 bg-gray-300 rounded"></div>
                            </div>
                            <div className="flex justify-between">
                              <div className="w-24 h-3 bg-gray-300 rounded"></div>
                              <div className="w-16 h-3 bg-gray-300 rounded"></div>
                            </div>
                          </div>
                          <div className="mt-8">
                            <div className="w-full h-10 bg-brand-500 rounded-md"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
