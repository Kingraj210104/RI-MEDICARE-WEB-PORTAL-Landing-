
import { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CreditCard, Search, CheckCircle, XCircle, AlertCircle } from "lucide-react";
import { toast } from "@/hooks/use-toast";

const HealthCardManagement = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPatient, setSelectedPatient] = useState<any>(null);

  // Mock patient health card data
  const [patients, setPatients] = useState([
    {
      id: 1,
      name: "Rahul Sharma",
      healthCardId: "HC78901",
      balance: 25000,
      status: "Active",
      lastTransaction: "21/11/2023"
    },
    {
      id: 2,
      name: "Priya Patel",
      healthCardId: "HC78902",
      balance: 1500,
      status: "Active",
      lastTransaction: "18/11/2023"
    },
    {
      id: 3,
      name: "Amit Singh",
      healthCardId: "HC78903",
      balance: 40000,
      status: "Active",
      lastTransaction: "15/11/2023"
    },
    {
      id: 4,
      name: "Deepika Mehta",
      healthCardId: "HC78904",
      balance: 0,
      status: "Inactive",
      lastTransaction: "05/10/2023"
    },
    {
      id: 5,
      name: "Rajiv Kumar",
      healthCardId: "HC78905",
      balance: 8500,
      status: "Active",
      lastTransaction: "12/11/2023"
    }
  ]);

  // Filter patients based on search term
  const filteredPatients = patients.filter(
    (patient) =>
      patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.healthCardId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  // Handle verifying health card
  const handleVerifyCard = (patient: any) => {
    setSelectedPatient(patient);
  };

  // Handle making payment from health card
  const handleProcessPayment = (amount: number) => {
    if (!selectedPatient) return;

    if (selectedPatient.balance < amount) {
      toast({
        title: "Insufficient Balance",
        description: "Patient's health card has insufficient balance for this transaction.",
        variant: "destructive"
      });
      return;
    }

    // Update patient balance
    const updatedPatients = patients.map(patient => {
      if (patient.id === selectedPatient.id) {
        return {
          ...patient,
          balance: patient.balance - amount,
          lastTransaction: new Date().toLocaleDateString('en-GB')
        };
      }
      return patient;
    });

    setPatients(updatedPatients);
    
    // Also update selected patient
    setSelectedPatient({
      ...selectedPatient,
      balance: selectedPatient.balance - amount,
      lastTransaction: new Date().toLocaleDateString('en-GB')
    });

    toast({
      title: "Payment Processed Successfully",
      description: `₹${amount} has been deducted from ${selectedPatient.name}'s health card.`
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Health Card Management</CardTitle>
              <CardDescription>Verify and manage patient health cards</CardDescription>
            </div>
            <CreditCard className="h-8 w-8 text-primary" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center mb-6 gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by patient name or health card ID..."
                className="pl-8"
                value={searchTerm}
                onChange={handleSearchChange}
              />
            </div>
            <Dialog>
              <DialogTrigger asChild>
                <Button>Scan Health Card</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Scan Health Card</DialogTitle>
                  <DialogDescription>
                    Scan QR code or enter health card details manually
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="border-2 border-dashed rounded-lg p-12 flex items-center justify-center">
                    <p className="text-muted-foreground text-center">
                      Point scanner at health card QR code<br/>
                      <span className="text-sm">or</span><br/>
                      Enter details manually below
                    </p>
                  </div>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <Label htmlFor="manual-id">Health Card ID</Label>
                      <Input id="manual-id" placeholder="Enter HC ID..." />
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline">Cancel</Button>
                  <Button>Verify Card</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          {filteredPatients.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Patient Name</TableHead>
                  <TableHead>Health Card ID</TableHead>
                  <TableHead>Balance</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Transaction</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPatients.map((patient) => (
                  <TableRow key={patient.id}>
                    <TableCell>{patient.name}</TableCell>
                    <TableCell className="font-medium">{patient.healthCardId}</TableCell>
                    <TableCell>₹{patient.balance.toLocaleString()}</TableCell>
                    <TableCell>
                      {patient.status === "Active" ? (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Active
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                          Inactive
                        </span>
                      )}
                    </TableCell>
                    <TableCell>{patient.lastTransaction}</TableCell>
                    <TableCell>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleVerifyCard(patient)}
                          >
                            Verify
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[500px]">
                          <DialogHeader>
                            <DialogTitle>Health Card Verification</DialogTitle>
                            <DialogDescription>
                              Verify health card details and process payment
                            </DialogDescription>
                          </DialogHeader>
                          {selectedPatient && patient.id === selectedPatient.id && (
                            <div className="grid gap-4 py-4">
                              <div className="border rounded-lg p-4">
                                <div className="flex justify-between items-center mb-2">
                                  <span className="font-medium">Patient:</span>
                                  <span>{selectedPatient.name}</span>
                                </div>
                                <div className="flex justify-between items-center mb-2">
                                  <span className="font-medium">Health Card ID:</span>
                                  <span>{selectedPatient.healthCardId}</span>
                                </div>
                                <div className="flex justify-between items-center mb-2">
                                  <span className="font-medium">Available Balance:</span>
                                  <span className={`font-bold ${selectedPatient.balance < 5000 ? 'text-red-600' : 'text-green-600'}`}>
                                    ₹{selectedPatient.balance.toLocaleString()}
                                  </span>
                                </div>
                                <div className="flex justify-between items-center">
                                  <span className="font-medium">Card Status:</span>
                                  <span className="flex items-center gap-1">
                                    {selectedPatient.status === "Active" ? (
                                      <>
                                        <CheckCircle className="h-4 w-4 text-green-600" />
                                        <span className="text-green-600">Active</span>
                                      </>
                                    ) : (
                                      <>
                                        <XCircle className="h-4 w-4 text-red-600" />
                                        <span className="text-red-600">Inactive</span>
                                      </>
                                    )}
                                  </span>
                                </div>
                              </div>
                              
                              {selectedPatient.status === "Active" ? (
                                <div>
                                  <Label htmlFor="payment-amount">Process Payment</Label>
                                  <div className="flex items-center gap-2 mt-2">
                                    <Input 
                                      id="payment-amount" 
                                      type="number" 
                                      placeholder="Enter amount" 
                                    />
                                    <Button onClick={() => handleProcessPayment(5000)}>
                                      Deduct ₹5,000
                                    </Button>
                                  </div>
                                  
                                  {selectedPatient.balance < 5000 && (
                                    <div className="flex items-center gap-2 mt-3 text-amber-600 text-sm">
                                      <AlertCircle className="h-4 w-4" />
                                      <span>Low balance. Consider applying for a patient loan.</span>
                                    </div>
                                  )}
                                </div>
                              ) : (
                                <div className="bg-red-50 border border-red-200 rounded p-3 text-red-800 text-sm">
                                  This health card is inactive. Payment cannot be processed.
                                </div>
                              )}
                            </div>
                          )}
                          <DialogFooter className="gap-2 sm:gap-0">
                            <Button variant="outline">Close</Button>
                            {selectedPatient && selectedPatient.status === "Active" && selectedPatient.balance < 5000 && (
                              <Button variant="secondary">Apply for Loan</Button>
                            )}
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-10">
              <p className="text-muted-foreground">No health cards found matching your search criteria.</p>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="ml-auto">View All Health Cards</Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default HealthCardManagement;
