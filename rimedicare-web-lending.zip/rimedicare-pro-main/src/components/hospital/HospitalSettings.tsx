
import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Building,
  UserCog,
  Bell,
  Shield,
  BanknoteIcon,
  LockIcon,
  Settings,
  Users,
  CheckCircle,
  AlertCircle,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

const HospitalSettings = () => {
  const [loading, setLoading] = useState(false);

  // Mock hospital data
  const [hospitalData, setHospitalData] = useState({
    name: "City General Hospital",
    email: "admin@citygeneralhospital.com",
    phone: "9876543210",
    address: "123 Health Avenue",
    city: "Mumbai",
    state: "Maharashtra",
    zipCode: "400001",
    registrationNumber: "HOSP12345",
    establishedYear: "1995",
    specialties: ["General", "Cardiology", "Orthopedics", "Neurology"],
    services: ["OPD", "IPD", "Surgery", "Emergency"],
    accountNumber: "2010XXXXXXX4589",
    ifscCode: "HDFC0001234",
    accountHolderName: "City General Hospital",
    bankName: "HDFC Bank",
    branchName: "Mumbai Main Branch",
    notificationSettings: {
      emailAlerts: true,
      smsAlerts: true,
      paymentNotifications: true,
      loanUpdates: true
    },
    complianceStatus: "Verified",
    verificationDate: "15/10/2023",
    nextVerificationDate: "15/10/2024",
    platformCommission: "5%"
  });

  // Handle profile update
  const handleUpdateProfile = () => {
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Profile Updated",
        description: "Your hospital profile has been updated successfully.",
      });
    }, 1000);
  };

  // Handle bank details update
  const handleUpdateBankDetails = () => {
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Bank Details Updated",
        description: "Your bank account details have been updated successfully.",
      });
    }, 1000);
  };

  // Handle notification settings update
  const handleUpdateNotifications = () => {
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Notification Settings Updated",
        description: "Your notification preferences have been updated successfully.",
      });
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Hospital Settings</CardTitle>
              <CardDescription>Manage your hospital profile and settings</CardDescription>
            </div>
            <Building className="h-8 w-8 text-primary" />
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="profile" className="w-full">
            <TabsList className="mb-6 bg-white border">
              <TabsTrigger value="profile">Hospital Profile</TabsTrigger>
              <TabsTrigger value="bank">Bank Details</TabsTrigger>
              <TabsTrigger value="users">User Management</TabsTrigger>
              <TabsTrigger value="compliance">Compliance & Verification</TabsTrigger>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
            </TabsList>
            
            <TabsContent value="profile" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="hospital-name">Hospital Name</Label>
                  <Input 
                    id="hospital-name" 
                    value={hospitalData.name} 
                    onChange={(e) => setHospitalData({...hospitalData, name: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="registration-number">Registration Number</Label>
                  <Input 
                    id="registration-number" 
                    value={hospitalData.registrationNumber} 
                    onChange={(e) => setHospitalData({...hospitalData, registrationNumber: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input 
                    id="email" 
                    type="email"
                    value={hospitalData.email} 
                    onChange={(e) => setHospitalData({...hospitalData, email: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input 
                    id="phone" 
                    value={hospitalData.phone} 
                    onChange={(e) => setHospitalData({...hospitalData, phone: e.target.value})}
                  />
                </div>
                <div className="md:col-span-2">
                  <Label htmlFor="address">Address</Label>
                  <Input 
                    id="address" 
                    value={hospitalData.address} 
                    onChange={(e) => setHospitalData({...hospitalData, address: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="city">City</Label>
                  <Input 
                    id="city" 
                    value={hospitalData.city} 
                    onChange={(e) => setHospitalData({...hospitalData, city: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="state">State</Label>
                  <Input 
                    id="state" 
                    value={hospitalData.state} 
                    onChange={(e) => setHospitalData({...hospitalData, state: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="zip-code">Zip Code</Label>
                  <Input 
                    id="zip-code" 
                    value={hospitalData.zipCode} 
                    onChange={(e) => setHospitalData({...hospitalData, zipCode: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="established-year">Established Year</Label>
                  <Input 
                    id="established-year" 
                    value={hospitalData.establishedYear} 
                    onChange={(e) => setHospitalData({...hospitalData, establishedYear: e.target.value})}
                  />
                </div>
                <div className="md:col-span-2">
                  <Label>Hospital Specialties</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {hospitalData.specialties.map((specialty, index) => (
                      <div key={index} className="bg-primary/10 text-primary rounded-full px-3 py-1 text-sm">
                        {specialty}
                      </div>
                    ))}
                    <Button variant="outline" size="sm" className="rounded-full">
                      + Add
                    </Button>
                  </div>
                </div>
                <div className="md:col-span-2 flex justify-end gap-2">
                  <Button variant="outline">Cancel</Button>
                  <Button onClick={handleUpdateProfile} disabled={loading}>
                    {loading ? "Saving..." : "Save Changes"}
                  </Button>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="bank" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="account-holder">Account Holder Name</Label>
                  <Input 
                    id="account-holder" 
                    value={hospitalData.accountHolderName} 
                    onChange={(e) => setHospitalData({...hospitalData, accountHolderName: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="bank-name">Bank Name</Label>
                  <Input 
                    id="bank-name" 
                    value={hospitalData.bankName} 
                    onChange={(e) => setHospitalData({...hospitalData, bankName: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="account-number">Account Number</Label>
                  <Input 
                    id="account-number" 
                    value={hospitalData.accountNumber} 
                    onChange={(e) => setHospitalData({...hospitalData, accountNumber: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="ifsc-code">IFSC Code</Label>
                  <Input 
                    id="ifsc-code" 
                    value={hospitalData.ifscCode} 
                    onChange={(e) => setHospitalData({...hospitalData, ifscCode: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="branch-name">Branch Name</Label>
                  <Input 
                    id="branch-name" 
                    value={hospitalData.branchName} 
                    onChange={(e) => setHospitalData({...hospitalData, branchName: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="account-type">Account Type</Label>
                  <Select defaultValue="current">
                    <SelectTrigger id="account-type">
                      <SelectValue placeholder="Select account type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="current">Current</SelectItem>
                      <SelectItem value="savings">Savings</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="md:col-span-2 flex justify-end gap-2">
                  <Button variant="outline">Cancel</Button>
                  <Button onClick={handleUpdateBankDetails} disabled={loading}>
                    {loading ? "Saving..." : "Save Changes"}
                  </Button>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="users" className="space-y-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium">Hospital Users</h3>
                <Button>
                  <Users className="h-4 w-4 mr-2" />
                  Add User
                </Button>
              </div>
              
              <div className="border rounded-lg overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    <tr className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm font-medium">Dr. Rajesh Kumar</td>
                      <td className="px-4 py-3 text-sm">rajesh@citygeneralhospital.com</td>
                      <td className="px-4 py-3 text-sm">Administrator</td>
                      <td className="px-4 py-3 text-sm">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Active
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">Edit</Button>
                          <Button variant="ghost" size="sm" className="text-red-600">Deactivate</Button>
                        </div>
                      </td>
                    </tr>
                    <tr className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm font-medium">Dr. Priya Sharma</td>
                      <td className="px-4 py-3 text-sm">priya@citygeneralhospital.com</td>
                      <td className="px-4 py-3 text-sm">Payment Operator</td>
                      <td className="px-4 py-3 text-sm">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Active
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">Edit</Button>
                          <Button variant="ghost" size="sm" className="text-red-600">Deactivate</Button>
                        </div>
                      </td>
                    </tr>
                    <tr className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm font-medium">Anand Mehta</td>
                      <td className="px-4 py-3 text-sm">anand@citygeneralhospital.com</td>
                      <td className="px-4 py-3 text-sm">Finance Manager</td>
                      <td className="px-4 py-3 text-sm">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Active
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">Edit</Button>
                          <Button variant="ghost" size="sm" className="text-red-600">Deactivate</Button>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </TabsContent>
            
            <TabsContent value="compliance" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-lg">Verification Status</CardTitle>
                      {hospitalData.complianceStatus === "Verified" ? (
                        <div className="flex items-center text-green-600">
                          <CheckCircle className="h-5 w-5 mr-1" />
                          <span>Verified</span>
                        </div>
                      ) : (
                        <div className="flex items-center text-amber-600">
                          <AlertCircle className="h-5 w-5 mr-1" />
                          <span>Pending</span>
                        </div>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Last Verified</span>
                        <span className="text-sm font-medium">{hospitalData.verificationDate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Next Verification Due</span>
                        <span className="text-sm font-medium">{hospitalData.nextVerificationDate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Platform Commission</span>
                        <span className="text-sm font-medium">{hospitalData.platformCommission}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Required Documents</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      <li className="flex items-center justify-between text-sm">
                        <span>Hospital Registration Certificate</span>
                        <span className="text-green-600 flex items-center">
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Uploaded
                        </span>
                      </li>
                      <li className="flex items-center justify-between text-sm">
                        <span>Tax Registration Certificate</span>
                        <span className="text-green-600 flex items-center">
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Uploaded
                        </span>
                      </li>
                      <li className="flex items-center justify-between text-sm">
                        <span>Medical License</span>
                        <span className="text-green-600 flex items-center">
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Uploaded
                        </span>
                      </li>
                      <li className="flex items-center justify-between text-sm">
                        <span>Bank Details Verification</span>
                        <span className="text-green-600 flex items-center">
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Verified
                        </span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card className="md:col-span-2">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Terms & Compliance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-4">
                      As a registered hospital on the RI Medicare platform, you agree to abide by our terms and conditions, including platform commissions, payment processing, and data privacy regulations.
                    </p>
                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <Switch id="terms" checked={true} />
                        <Label htmlFor="terms">I agree to the RI Medicare Terms of Service</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="privacy" checked={true} />
                        <Label htmlFor="privacy">I agree to the Data Privacy Policy</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="commission" checked={true} />
                        <Label htmlFor="commission">I accept the platform commission of 5% on all transactions</Label>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="notifications" className="space-y-6">
              <div className="space-y-6">
                <h3 className="text-lg font-medium">Notification Preferences</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Email Notifications</p>
                      <p className="text-sm text-muted-foreground">Receive important updates via email</p>
                    </div>
                    <Switch 
                      checked={hospitalData.notificationSettings.emailAlerts} 
                      onCheckedChange={(checked) => 
                        setHospitalData({
                          ...hospitalData, 
                          notificationSettings: {
                            ...hospitalData.notificationSettings,
                            emailAlerts: checked
                          }
                        })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">SMS Alerts</p>
                      <p className="text-sm text-muted-foreground">Receive urgent notifications via SMS</p>
                    </div>
                    <Switch 
                      checked={hospitalData.notificationSettings.smsAlerts} 
                      onCheckedChange={(checked) => 
                        setHospitalData({
                          ...hospitalData, 
                          notificationSettings: {
                            ...hospitalData.notificationSettings,
                            smsAlerts: checked
                          }
                        })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Payment Notifications</p>
                      <p className="text-sm text-muted-foreground">Get alerts when payments are received or processed</p>
                    </div>
                    <Switch 
                      checked={hospitalData.notificationSettings.paymentNotifications} 
                      onCheckedChange={(checked) => 
                        setHospitalData({
                          ...hospitalData, 
                          notificationSettings: {
                            ...hospitalData.notificationSettings,
                            paymentNotifications: checked
                          }
                        })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Loan Updates</p>
                      <p className="text-sm text-muted-foreground">Receive updates on patient loan applications</p>
                    </div>
                    <Switch 
                      checked={hospitalData.notificationSettings.loanUpdates} 
                      onCheckedChange={(checked) => 
                        setHospitalData({
                          ...hospitalData, 
                          notificationSettings: {
                            ...hospitalData.notificationSettings,
                            loanUpdates: checked
                          }
                        })
                      }
                    />
                  </div>
                </div>
                
                <div className="pt-6 border-t flex justify-end gap-2">
                  <Button variant="outline">Reset to Default</Button>
                  <Button onClick={handleUpdateNotifications} disabled={loading}>
                    {loading ? "Saving..." : "Save Preferences"}
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default HospitalSettings;
