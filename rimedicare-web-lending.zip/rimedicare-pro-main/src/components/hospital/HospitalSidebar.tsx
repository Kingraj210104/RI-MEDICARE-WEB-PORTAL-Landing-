
import { Link } from "react-router-dom";
import {
  Wallet,
  CreditCard,
  LayoutDashboard,
  ClipboardList,
  Users,
  LogOut,
  Menu,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface SidebarProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

const HospitalSidebar = ({ isOpen, setIsOpen }: SidebarProps) => {
  const handleLogout = () => {
    // Clear authentication data
    localStorage.removeItem("hospitalAuthToken");
    // Redirect to login page
    window.location.href = "/login";
  };

  return (
    <>
      {/* Mobile sidebar backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40 bg-black bg-opacity-50 lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 transform bg-white border-r border-gray-200 transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:z-auto ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Logo and close button for mobile */}
          <div className="flex items-center justify-between p-4 border-b">
            <Link to="/" className="flex items-center space-x-2">
              <div className="font-display font-bold text-xl text-gradient">
                RI <span className="text-medicare-600">Medicare</span>
              </div>
            </Link>
            <button
              className="p-1 rounded-md hover:bg-gray-100 lg:hidden"
              onClick={() => setIsOpen(false)}
            >
              <X size={20} />
            </button>
          </div>

          {/* Navigation links */}
          <nav className="flex-1 p-4 space-y-1">
            <p className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
              Main
            </p>
            <Link
              to="/hospital-dashboard"
              className="flex items-center space-x-3 px-3 py-2 rounded-md text-gray-700 hover:bg-brand-50 hover:text-brand-600"
            >
              <LayoutDashboard size={20} />
              <span>Dashboard</span>
            </Link>
            
            <Link
              to="/hospital-dashboard?tab=wallet"
              className="flex items-center space-x-3 px-3 py-2 rounded-md text-gray-700 hover:bg-brand-50 hover:text-brand-600"
            >
              <Wallet size={20} />
              <span>Wallet Management</span>
            </Link>
            
            <Link
              to="/hospital-dashboard?tab=transactions"
              className="flex items-center space-x-3 px-3 py-2 rounded-md text-gray-700 hover:bg-brand-50 hover:text-brand-600"
            >
              <ClipboardList size={20} />
              <span>Transactions</span>
            </Link>
            
            <Link
              to="/hospital-dashboard?tab=payments"
              className="flex items-center space-x-3 px-3 py-2 rounded-md text-gray-700 hover:bg-brand-50 hover:text-brand-600"
            >
              <CreditCard size={20} />
              <span>Process Payment</span>
            </Link>
            
            <p className="mt-6 px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
              Settings
            </p>
            
            <Link
              to="/hospital-dashboard?tab=users"
              className="flex items-center space-x-3 px-3 py-2 rounded-md text-gray-700 hover:bg-brand-50 hover:text-brand-600"
            >
              <Users size={20} />
              <span>User Management</span>
            </Link>
          </nav>

          {/* Logout button */}
          <div className="p-4 border-t">
            <Button
              variant="outline"
              className="w-full flex items-center justify-center space-x-2"
              onClick={handleLogout}
            >
              <LogOut size={18} />
              <span>Logout</span>
            </Button>
          </div>
        </div>
      </aside>
    </>
  );
};

export default HospitalSidebar;
