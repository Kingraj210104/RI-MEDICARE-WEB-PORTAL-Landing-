
import { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';
import PersonalDetailsForm from './PersonalDetailsForm';
import EmploymentLoanDetailsForm from './EmploymentLoanDetailsForm';
import DocumentUploadForm from './DocumentUploadForm';

const LoanApplicationForm = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [referenceNumber, setReferenceNumber] = useState('');
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    dob: '',
    address: '',
    employmentType: 'salaried',
    companyName: '',
    monthlyIncome: '',
    hospitalName: '',
    loanAmount: '',
    repaymentTenure: '12',
    documents: {
      aadhaar: null,
      pan: null,
      bankStatement: null,
    }
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, files } = e.target;
    if (files && files[0]) {
      setFormData(prev => ({
        ...prev,
        documents: {
          ...prev.documents,
          [name]: files[0]
        }
      }));

      toast({
        title: "Document uploaded",
        description: `Successfully uploaded ${files[0].name}`,
      });
    }
  };

  const generateReferenceNumber = () => {
    const date = new Date();
    const year = date.getFullYear().toString().slice(-2);
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const random = Math.floor(10000 + Math.random() * 90000);
    return `RI${year}${month}${day}-${random}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const generatedRefNumber = generateReferenceNumber();
    setReferenceNumber(generatedRefNumber);
    setIsSubmitted(true);
    
    toast({
      title: "Application Submitted",
      description: `We've received your loan application. Reference Number: ${generatedRefNumber}`,
    });
    
    // Here you would normally send the data to a server
    console.log("Form submitted:", formData);
    console.log("Reference Number:", generatedRefNumber);
  };

  const nextStep = () => {
    setCurrentStep(prev => Math.min(prev + 1, 3));
    window.scrollTo(0, 0);
  };

  const prevStep = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
    window.scrollTo(0, 0);
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <PersonalDetailsForm 
            formData={formData} 
            handleInputChange={handleInputChange} 
          />
        );
      case 2:
        return (
          <EmploymentLoanDetailsForm 
            formData={formData} 
            handleInputChange={handleInputChange} 
          />
        );
      case 3:
        return (
          <DocumentUploadForm 
            formData={formData} 
            handleFileChange={handleFileChange} 
          />
        );
      default:
        return null;
    }
  };

  const handleStartNewApplication = () => {
    setFormData({
      fullName: '',
      email: '',
      phone: '',
      dob: '',
      address: '',
      employmentType: 'salaried',
      companyName: '',
      monthlyIncome: '',
      hospitalName: '',
      loanAmount: '',
      repaymentTenure: '12',
      documents: {
        aadhaar: null,
        pan: null,
        bankStatement: null,
      }
    });
    setCurrentStep(1);
    setIsSubmitted(false);
    setReferenceNumber('');
  };

  return (
    <section className="py-12">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="max-w-4xl mx-auto">
          {!isSubmitted ? (
            <div className={`bg-white rounded-xl shadow-sm border border-gray-100 p-6 md:p-10 animate-fade-in`}>
              <form onSubmit={handleSubmit}>
                {renderStepContent()}
                
                <div className="mt-8 flex justify-between">
                  {currentStep > 1 && (
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={prevStep}
                    >
                      Previous
                    </Button>
                  )}
                  
                  <div className="ml-auto">
                    {currentStep < 3 ? (
                      <Button 
                        type="button" 
                        onClick={nextStep}
                        className="bg-brand-600 hover:bg-brand-700"
                      >
                        Next
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    ) : (
                      <Button 
                        type="submit" 
                        className="bg-brand-600 hover:bg-brand-700"
                      >
                        Submit Application
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </form>
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 md:p-10 animate-fade-in text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                </svg>
              </div>
              
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Application Submitted Successfully!</h2>
              <p className="text-gray-600 mb-6">Thank you for your application. Our team will review it shortly.</p>
              
              <div className="bg-gray-50 p-6 rounded-lg mb-8">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Your Application Reference Number:</h3>
                <p className="text-2xl font-bold text-brand-600 font-mono">{referenceNumber}</p>
                <p className="text-sm text-gray-500 mt-2">Please save this reference number for future communication.</p>
              </div>
              
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button 
                  type="button"
                  variant="outline"
                  onClick={handleStartNewApplication}
                  className="w-full sm:w-auto"
                >
                  Start New Application
                </Button>
                <Button 
                  type="button"
                  className="bg-brand-600 hover:bg-brand-700 w-full sm:w-auto"
                  onClick={() => window.location.href = '/'}
                >
                  Return to Home
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default LoanApplicationForm;
