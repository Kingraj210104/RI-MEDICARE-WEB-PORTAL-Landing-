
import React from 'react';

const LoanHeroSection = () => {
  return (
    <section className="py-12 md:py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-block bg-brand-50 px-3 py-1 rounded-full text-brand-700 font-medium text-sm mb-4">
            Quick Loan Approval | 90 Days Interest-Free | Minimal Documentation
          </div>
          <h1 className="text-3xl md:text-5xl font-bold font-display text-gray-900 mb-4">
            Apply for a Medical Loan
          </h1>
          <p className="text-xl text-gray-600 mb-0">
            Get medical treatment today, pay later with flexible EMI options
          </p>
        </div>
      </div>
    </section>
  );
};

export default LoanHeroSection;
