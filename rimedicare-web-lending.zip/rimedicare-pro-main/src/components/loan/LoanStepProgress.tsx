
import { useState, useEffect } from 'react';

const LoanStepProgress = () => {
  const [currentStep, setCurrentStep] = useState(1);

  useEffect(() => {
    const handleStorageChange = () => {
      const storedStep = sessionStorage.getItem('loanApplicationStep');
      if (storedStep) {
        setCurrentStep(parseInt(storedStep));
      }
    };

    handleStorageChange();
    window.addEventListener('storage', handleStorageChange);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  return (
    <section className="py-6 bg-white border-b border-gray-100">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="max-w-4xl mx-auto">
          <div className="relative flex items-center justify-between">
            <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-1 bg-gray-200 z-0"></div>
            
            {[1, 2, 3].map((step) => (
              <div 
                key={step}
                className={`relative z-10 flex flex-col items-center ${
                  currentStep >= step ? 'text-brand-600' : 'text-gray-400'
                }`}
              >
                <div 
                  className={`w-10 h-10 flex items-center justify-center rounded-full font-medium ${
                    currentStep >= step 
                      ? 'bg-brand-100 text-brand-600' 
                      : 'bg-gray-100 text-gray-400'
                  }`}
                >
                  {step}
                </div>
                <div className="mt-2 text-sm font-medium">
                  {step === 1 ? 'Personal' : step === 2 ? 'Employment & Loan' : 'Documents'}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default LoanStepProgress;
