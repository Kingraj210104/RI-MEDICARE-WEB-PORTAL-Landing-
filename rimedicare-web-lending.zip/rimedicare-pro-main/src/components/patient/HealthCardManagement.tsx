
import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CreditCard, Download, PlusCircle } from "lucide-react";
import { toast } from "@/hooks/use-toast";

const HealthCardManagement = () => {
  // Mock data
  const [healthCardData, setHealthCardData] = useState({
    cardNumber: "HC-78901-23456",
    availableBalance: 25000,
    usedAmount: 15000,
    totalCredit: 40000,
    expiryDate: "31/12/2026",
    lastTransaction: "20/11/2023",
  });

  const recentTransactions = [
    { date: "22/11/2023", hospital: "City General Hospital", service: "Consultation", amount: 2500, status: "Completed" },
    { date: "15/11/2023", hospital: "Medicare Pharmacy", service: "Medication", amount: 1800, status: "Completed" },
    { date: "10/11/2023", hospital: "City General Hospital", service: "Lab Tests", amount: 3500, status: "Completed" },
    { date: "05/11/2023", hospital: "Wellness Clinic", service: "Physiotherapy", amount: 1200, status: "Completed" },
  ];

  const handleAddMoney = () => {
    toast({
      title: "Add Money to Health Card",
      description: "Please use UPI or net banking to add money to your health card.",
    });
  };

  const handleDownloadStatement = () => {
    toast({
      title: "Statement Download",
      description: "Your health card statement is being downloaded.",
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Your Health Card</CardTitle>
              <CardDescription>Manage your medical expenses with ease</CardDescription>
            </div>
            <CreditCard className="h-8 w-8 text-primary" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="p-4 bg-primary/10 rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Available Balance</p>
              <p className="text-2xl font-bold">₹{healthCardData.availableBalance.toLocaleString()}</p>
            </div>
            <div className="p-4 bg-primary/10 rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Used Credit</p>
              <p className="text-2xl font-bold">₹{healthCardData.usedAmount.toLocaleString()}</p>
            </div>
            <div className="p-4 bg-primary/10 rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Total Credit Limit</p>
              <p className="text-2xl font-bold">₹{healthCardData.totalCredit.toLocaleString()}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <p className="text-sm text-muted-foreground">Card Number</p>
              <p className="font-medium">{healthCardData.cardNumber}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Expiry Date</p>
              <p className="font-medium">{healthCardData.expiryDate}</p>
            </div>
          </div>
          
          <div className="relative pt-2">
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-primary h-2.5 rounded-full" 
                style={{ width: `${(healthCardData.usedAmount / healthCardData.totalCredit) * 100}%` }}
              ></div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              You've used {Math.round((healthCardData.usedAmount / healthCardData.totalCredit) * 100)}% of your total credit limit
            </p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={handleAddMoney}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Money
          </Button>
          <Button variant="outline" onClick={handleDownloadStatement}>
            <Download className="mr-2 h-4 w-4" />
            Download Statement
          </Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
          <CardDescription>Your recent health card usage</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Hospital</TableHead>
                <TableHead>Service</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recentTransactions.map((transaction, index) => (
                <TableRow key={index}>
                  <TableCell>{transaction.date}</TableCell>
                  <TableCell>{transaction.hospital}</TableCell>
                  <TableCell>{transaction.service}</TableCell>
                  <TableCell className="text-right">₹{transaction.amount.toLocaleString()}</TableCell>
                  <TableCell>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      {transaction.status}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="ml-auto">View All Transactions</Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default HealthCardManagement;
