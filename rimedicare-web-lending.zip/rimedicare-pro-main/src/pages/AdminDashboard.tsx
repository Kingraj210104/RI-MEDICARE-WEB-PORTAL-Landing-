
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AdminDashboardHeader from "@/components/admin/AdminDashboardHeader";
import AdminSidebar from "@/components/admin/AdminSidebar";
import AdminDashboardOverview from "@/components/admin/AdminDashboardOverview";
import LoanApproval from "@/components/admin/LoanApproval";
import HospitalManagement from "@/components/admin/HospitalManagement";
import { SidebarProvider } from "@/components/ui/sidebar";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // In a real app, this would be fetched from an API after authentication
  const [adminData, setAdminData] = useState({
    adminName: "Admin User",
    adminId: "A12345",
    role: "System Administrator",
  });

  // Simulate authentication check (simplified for demo)
  // In a real app, use proper auth state management
  const isAuthenticated = true; // localStorage.getItem("adminAuthToken");
  
  if (!isAuthenticated) {
    // Redirect to login if not authenticated
    navigate("/login");
    return null;
  }

  return (
    <SidebarProvider>
      <div className="flex h-screen bg-gray-50">
        <AdminSidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />
        
        <div className="flex-1 overflow-auto">
          <AdminDashboardHeader 
            adminName={adminData.adminName}
            toggleSidebar={() => setSidebarOpen(!sidebarOpen)}
          />
          
          <main className="p-6">
            <Tabs defaultValue="overview" className="space-y-6">
              <TabsList className="bg-white border">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="loans">Loan Approvals</TabsTrigger>
                <TabsTrigger value="hospitals">Hospitals</TabsTrigger>
                <TabsTrigger value="health-cards">Health Cards</TabsTrigger>
                <TabsTrigger value="platform">Platform Fees</TabsTrigger>
                <TabsTrigger value="settings">Settings</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="mt-6">
                <AdminDashboardOverview />
              </TabsContent>
              
              <TabsContent value="loans" className="mt-6">
                <LoanApproval />
              </TabsContent>
              
              <TabsContent value="hospitals" className="mt-6">
                <HospitalManagement />
              </TabsContent>
              
              <TabsContent value="health-cards" className="mt-6">
                <div className="text-center py-10">
                  <h2 className="text-2xl font-bold mb-4">Health Card Management</h2>
                  <p className="text-gray-500">Health card management features coming soon.</p>
                </div>
              </TabsContent>
              
              <TabsContent value="platform" className="mt-6">
                <div className="text-center py-10">
                  <h2 className="text-2xl font-bold mb-4">Platform Fee Management</h2>
                  <p className="text-gray-500">Platform fee management features coming soon.</p>
                </div>
              </TabsContent>
              
              <TabsContent value="settings" className="mt-6">
                <div className="text-center py-10">
                  <h2 className="text-2xl font-bold mb-4">System Settings</h2>
                  <p className="text-gray-500">System settings and configuration coming soon.</p>
                </div>
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
};

export default AdminDashboard;
