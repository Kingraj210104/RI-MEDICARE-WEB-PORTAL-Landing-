
import { useState, useEffect } from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import LoanApplicationForm from '@/components/loan/LoanApplicationForm';
import LoanHeroSection from '@/components/loan/LoanHeroSection';
import LoanStepProgress from '@/components/loan/LoanStepProgress';
import LoanFeatures from '@/components/loan/LoanFeatures';
import LoanProcess from '@/components/loan/LoanProcess';
import LoanCta from '@/components/loan/LoanCta';

const ApplyLoan = () => {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setLoaded(true);
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-20">
        <LoanHeroSection />
        <LoanStepProgress />
        <LoanApplicationForm />
        <LoanFeatures loaded={loaded} />
        <LoanProcess loaded={loaded} />
        <LoanCta />
      </main>

      <Footer />
    </div>
  );
};

export default ApplyLoan;
