
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import HospitalDashboardHeader from "@/components/hospital/HospitalDashboardHeader";
import HospitalSidebar from "@/components/hospital/HospitalSidebar";
import DashboardOverview from "@/components/hospital/DashboardOverview";
import WalletManagement from "@/components/hospital/WalletManagement";
import TransactionHistory from "@/components/hospital/TransactionHistory";
import PaymentProcessor from "@/components/hospital/PaymentProcessor";
import UserManagement from "@/components/hospital/UserManagement";
import PatientManagement from "@/components/hospital/PatientManagement";
import LoanApplications from "@/components/hospital/LoanApplications";
import SupportAndDisputes from "@/components/hospital/SupportAndDisputes";
import ReportsAndAnalytics from "@/components/hospital/ReportsAndAnalytics";
import HealthCardManagement from "@/components/hospital/HealthCardManagement";
import HospitalSettings from "@/components/hospital/HospitalSettings";
import { Toaster } from "@/components/ui/toaster";

const HospitalDashboard = () => {
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // In a real app, this would be fetched from an API after authentication
  const [hospitalData, setHospitalData] = useState({
    hospitalName: "City General Hospital",
    hospitalId: "CGH12345",
    email: "admin@citygeneralhospital.com",
  });

  // Check authentication status (simplified for demo)
  const isAuthenticated = localStorage.getItem("hospitalAuthToken");
  
  if (!isAuthenticated) {
    // Redirect to login if not authenticated
    navigate("/login");
    return null;
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <HospitalSidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />
      
      <div className="flex-1 overflow-auto">
        <HospitalDashboardHeader 
          hospitalName={hospitalData.hospitalName}
          toggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        />
        
        <main className="p-6">
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="bg-white border overflow-x-auto">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="patients">Patient Management</TabsTrigger>
              <TabsTrigger value="health-cards">Health Cards</TabsTrigger>
              <TabsTrigger value="payments">Process Payment</TabsTrigger>
              <TabsTrigger value="loans">Loan Applications</TabsTrigger>
              <TabsTrigger value="wallet">Wallet Management</TabsTrigger>
              <TabsTrigger value="transactions">Transactions</TabsTrigger>
              <TabsTrigger value="reports">Reports & Analytics</TabsTrigger>
              <TabsTrigger value="users">User Management</TabsTrigger>
              <TabsTrigger value="support">Support & Disputes</TabsTrigger>
              <TabsTrigger value="settings">Hospital Settings</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="mt-6">
              <DashboardOverview />
            </TabsContent>
            
            <TabsContent value="patients" className="mt-6">
              <PatientManagement />
            </TabsContent>
            
            <TabsContent value="health-cards" className="mt-6">
              <HealthCardManagement />
            </TabsContent>
            
            <TabsContent value="payments" className="mt-6">
              <PaymentProcessor />
            </TabsContent>
            
            <TabsContent value="loans" className="mt-6">
              <LoanApplications />
            </TabsContent>
            
            <TabsContent value="wallet" className="mt-6">
              <WalletManagement />
            </TabsContent>
            
            <TabsContent value="transactions" className="mt-6">
              <TransactionHistory />
            </TabsContent>
            
            <TabsContent value="reports" className="mt-6">
              <ReportsAndAnalytics />
            </TabsContent>
            
            <TabsContent value="users" className="mt-6">
              <UserManagement />
            </TabsContent>
            
            <TabsContent value="support" className="mt-6">
              <SupportAndDisputes />
            </TabsContent>
            
            <TabsContent value="settings" className="mt-6">
              <HospitalSettings />
            </TabsContent>
          </Tabs>
        </main>
      </div>
      <Toaster />
    </div>
  );
};

export default HospitalDashboard;
