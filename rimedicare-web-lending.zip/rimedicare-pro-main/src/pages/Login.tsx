import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { ArrowRight, Lock, Mail, User, Eye, EyeOff } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

const Login = () => {
  const navigate = useNavigate();
  const [loaded, setLoaded] = useState(false);
  const [userType, setUserType] = useState('patient');
  const [showPassword, setShowPassword] = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    phone: '',
    confirmPassword: '',
  });

  useEffect(() => {
    setLoaded(true);
    
    // Redirect to the external login system
    window.location.href = 'http://103.196.193.18/rimedicare_hospy/';
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Redirect to external login instead
    window.location.href = 'http://103.196.193.18/rimedicare_hospy/';
  };

  const toggleForm = () => {
    setIsLogin(!isLogin);
    // Reset form data when toggling between login and signup
    setFormData({
      email: '',
      password: '',
      name: '',
      phone: '',
      confirmPassword: '',
    });
  };

  // We're keeping the component but redirecting, so it likely won't render this part
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-20">
        <section className="py-12 md:py-16">
          <div className="container mx-auto px-4 sm:px-6">
            <div className="max-w-md mx-auto">
              <div className={`bg-white rounded-2xl shadow-sm border border-gray-100 p-8 transition-all duration-500 ${loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
                <div className="text-center mb-8">
                  <h1 className="text-2xl font-bold font-display text-gray-900 mb-2">
                    Redirecting to Login Portal
                  </h1>
                  <p className="text-gray-600">
                    You are being redirected to the RI Medicare login portal.
                  </p>
                </div>
                
                <div className="flex justify-center">
                  <a href="http://103.196.193.18/rimedicare_hospy/" className="block w-full">
                    <Button className="w-full bg-brand-600 hover:bg-brand-700">
                      Go to Login Portal
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </a>
                </div>
                
                {/* Quick access link for Patient Dashboard only */}
                <div className="mt-8 pt-6 border-t border-gray-200">
                  <p className="text-sm text-gray-500 mb-2 text-center">Quick access link for demo:</p>
                  <div className="flex flex-col space-y-2">
                    <Link to="/patient-dashboard" className="text-sm text-center text-brand-600 hover:text-brand-700">
                      Patient Dashboard
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Login;
