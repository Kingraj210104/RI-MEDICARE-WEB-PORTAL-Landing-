
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PatientSidebar from "@/components/patient/PatientSidebar";
import PatientDashboardHeader from "@/components/patient/PatientDashboardHeader";
import PatientDashboardOverview from "@/components/patient/PatientDashboardOverview";
import HealthCardManagement from "@/components/patient/HealthCardManagement";
import LoanManagement from "@/components/patient/LoanManagement";
import HospitalVisits from "@/components/patient/HospitalVisits";
import { SidebarProvider } from "@/components/ui/sidebar";

const PatientDashboard = () => {
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // In a real app, this would be fetched from an API after authentication
  const [patientData, setPatientData] = useState({
    patientName: "John Doe",
    patientId: "P12345",
    email: "john.doe@example.com",
    healthCardId: "HC-78901-23456",
  });

  // Simulate authentication check (simplified for demo)
  // In a real app, use proper auth state management
  const isAuthenticated = true; // localStorage.getItem("patientAuthToken");
  
  if (!isAuthenticated) {
    // Redirect to login if not authenticated
    navigate("/login");
    return null;
  }

  return (
    <SidebarProvider>
      <div className="flex h-screen bg-gray-50">
        <PatientSidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />
        
        <div className="flex-1 overflow-auto">
          <PatientDashboardHeader 
            patientName={patientData.patientName}
            toggleSidebar={() => setSidebarOpen(!sidebarOpen)}
          />
          
          <main className="p-6">
            <Tabs defaultValue="overview" className="space-y-6">
              <TabsList className="bg-white border">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="health-card">Health Card</TabsTrigger>
                <TabsTrigger value="loans">Loans & EMIs</TabsTrigger>
                <TabsTrigger value="hospital-visits">Hospital Visits</TabsTrigger>
                <TabsTrigger value="profile">Profile</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="mt-6">
                <PatientDashboardOverview />
              </TabsContent>
              
              <TabsContent value="health-card" className="mt-6">
                <HealthCardManagement />
              </TabsContent>
              
              <TabsContent value="loans" className="mt-6">
                <LoanManagement />
              </TabsContent>
              
              <TabsContent value="hospital-visits" className="mt-6">
                <HospitalVisits />
              </TabsContent>
              
              <TabsContent value="profile" className="mt-6">
                <div className="text-center py-10">
                  <h2 className="text-2xl font-bold mb-4">User Profile</h2>
                  <p className="text-gray-500">Profile management features coming soon.</p>
                </div>
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
};

export default PatientDashboard;
